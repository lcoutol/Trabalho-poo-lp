import java.util.ArrayList;
import java.util.List;

public class Estoque {
    private List<Produto> produtos;

    public Estoque() {
        this.produtos = new ArrayList<>();
    }

    public void adicionarProduto(Produto produto) {
        produtos.add(produto);
    }

    public List<Produto> listarProdutos() {
        return produtos;
    }

    public Produto buscarProduto(String nome) {
        for (Produto produto : produtos) {
            if (produto.getNome().equalsIgnoreCase(nome)) {
                return produto;
            }
        }
        return null;
    }

    public boolean verificarEstoque(Produto produto, int quantidade) {
        for (Produto p : produtos) {
            if (p.equals(produto)) {
                return p.getQuantidade() >= quantidade;
            }
        }
        return false;
    }

    public void atualizarEstoque(Produto produto, int quantidade) {
        for (Produto p : produtos) {
            if (p.equals(produto)) {
                p.setQuantidade(p.getQuantidade() - quantidade);
                break;
            }
        }
    }
}

