public class FinalizandoCompra {
    public boolean finalizarCompra(Carrinho carrinho, FormaPagamento formaPagamento) {
        // Simula a finalização da compra
        // Aqui poderia haver lógica para processar pagamento, enviar recibo, etc.
        return true;  // Retorna true se a compra foi finalizada com sucesso
    }
}


