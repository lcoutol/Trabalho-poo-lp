public enum FormaPagamento {
    CARTAO_CREDITO,
    CARTAO_DEBITO,
    BOLETO,
    DINHEIRO;
}


