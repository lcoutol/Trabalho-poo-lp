import javax.swing.SwingUtilities;

public class LojaDePerifericos {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TelaLogin telaLogin = new TelaLogin(); // Certifique-se de que existe um construtor sem argumentos em TelaLogin
            telaLogin.setVisible(true);
        });
    }
}













