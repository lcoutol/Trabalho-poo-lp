import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaLogin extends JFrame {

    private JTextField campoUsuario;
    private JPasswordField campoSenha;
    private JButton btnLogin;

    public TelaLogin() {
        setTitle("Login");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(255, 255, 255)); // Fundo branco

        JPanel panelCentral = new JPanel();
        panelCentral.setLayout(new GridLayout(3, 2, 10, 10));
        panelCentral.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panelCentral.setBackground(Color.WHITE);

        JLabel lblUsuario = new JLabel("Usuário:");
        campoUsuario = new JTextField();
        JLabel lblSenha = new JLabel("Senha:");
        campoSenha = new JPasswordField();
        btnLogin = new JButton("Login");

        // Cores personalizadas
        Color corFundoBotao = new Color(51, 153, 255); // Azul claro
        Color corTextoBotao = Color.WHITE;
        btnLogin.setBackground(corFundoBotao);
        btnLogin.setForeground(corTextoBotao);

        // Bordas e espaçamento
        lblUsuario.setBorder(BorderFactory.createEmptyBorder(0, 0, 5, 0));
        lblSenha.setBorder(BorderFactory.createEmptyBorder(0, 0, 5, 0));
        campoUsuario.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        campoSenha.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));

        panelCentral.add(lblUsuario);
        panelCentral.add(campoUsuario);
        panelCentral.add(lblSenha);
        panelCentral.add(campoSenha);

        JPanel panelBotoes = new JPanel();
        panelBotoes.setBackground(new Color(240, 240, 240)); // Fundo cinza claro
        panelBotoes.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelBotoes.setLayout(new FlowLayout(FlowLayout.CENTER));
        panelBotoes.add(btnLogin);

        add(panelCentral, BorderLayout.CENTER);
        add(panelBotoes, BorderLayout.SOUTH);

        btnLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String usuario = campoUsuario.getText();
                String senha = new String(campoSenha.getPassword());
                // Lógica de autenticação - exemplo simples
                if ("admin".equals(usuario) && "admin".equals(senha)) {
                    JOptionPane.showMessageDialog(null, "Login realizado com sucesso!");
                    // Aqui você pode abrir a próxima tela após o login
                    dispose(); // Fecha a tela de login após o login ser bem-sucedido
                    abrirTelaPrincipal(); // Exemplo de método para abrir a próxima tela
                } else {
                    JOptionPane.showMessageDialog(null, "Usuário ou senha incorretos. Tente novamente.");
                    // Limpar campos de login se o login falhar (opcional)
                    campoUsuario.setText("");
                    campoSenha.setText("");
                }
            }
        });
    }

    private void abrirTelaPrincipal() {
        SwingUtilities.invokeLater(() -> {
            new TelaVitrineProdutos().setVisible(true); // Exemplo de como abrir a próxima tela
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new TelaLogin().setVisible(true); // Exemplo de como iniciar a tela de login
        });
    }
}





