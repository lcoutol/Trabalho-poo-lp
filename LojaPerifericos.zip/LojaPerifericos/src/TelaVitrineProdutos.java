import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class TelaVitrineProdutos extends JFrame {

    private JLabel lblTitulo;
    private JPanel panelProdutos;
    private List<Produto> produtosDisponiveis;
    private List<Produto> produtosSelecionados;

    public TelaVitrineProdutos() {
        setTitle("Vitrine de Produtos");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(240, 240, 240)); // Fundo cinza claro

        // Inicializa a lista de produtos disponíveis (simulando produtos disponíveis)
        produtosDisponiveis = new ArrayList<>();
        produtosDisponiveis.add(new Produto("Teclado Mecânico", 200.0));
        produtosDisponiveis.add(new Produto("Mouse Gamer", 150.0));
        produtosDisponiveis.add(new Produto("Monitor 24''", 800.0));
        produtosDisponiveis.add(new Produto("Headset", 100.0));
        produtosDisponiveis.add(new Produto("Gabinete ATX", 300.0));
        produtosDisponiveis.add(new Produto("SSD 1TB", 500.0));
        produtosDisponiveis.add(new Produto("Memória RAM 16GB", 400.0));
        produtosDisponiveis.add(new Produto("Placa de Vídeo", 2000.0));
        produtosDisponiveis.add(new Produto("Placa Mãe", 600.0));
        produtosDisponiveis.add(new Produto("Fonte 750W", 350.0));

        produtosSelecionados = new ArrayList<>();

        // Painel superior com o título
        JPanel panelTitulo = new JPanel();
        panelTitulo.setBackground(new Color(65, 105, 225)); // Azul Royal
        panelTitulo.setBorder(new EmptyBorder(10, 10, 10, 10));
        lblTitulo = new JLabel("Produtos Disponíveis");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 28));
        lblTitulo.setForeground(Color.WHITE); // Texto branco
        panelTitulo.add(lblTitulo);

        add(panelTitulo, BorderLayout.NORTH);

        // Painel central para listar os produtos
        panelProdutos = new JPanel();
        panelProdutos.setLayout(new GridLayout(0, 3, 20, 20)); // Grid 3 colunas, espaçamento 20
        panelProdutos.setBorder(new EmptyBorder(20, 40, 20, 40)); // Margens internas
        panelProdutos.setBackground(Color.WHITE); // Fundo branco

        // Adiciona os produtos ao painel central
        for (Produto produto : produtosDisponiveis) {
            JPanel panelProduto = criarPanelProduto(produto);
            panelProdutos.add(panelProduto);
        }

        JScrollPane scrollPane = new JScrollPane(panelProdutos);
        add(scrollPane, BorderLayout.CENTER);

        // Botão para abrir o carrinho
        JButton btnCarrinho = new JButton("Ver Carrinho");
        btnCarrinho.setBackground(new Color(30, 144, 255)); // Azul Dodger
        btnCarrinho.setForeground(Color.WHITE); // Texto branco
        btnCarrinho.setFont(new Font("Arial", Font.BOLD, 16));
        btnCarrinho.setBorderPainted(false); // Sem borda
        btnCarrinho.setFocusPainted(false); // Sem foco
        btnCarrinho.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                abrirTelaCarrinho();
            }
        });

        JPanel panelBotoes = new JPanel();
        panelBotoes.setBackground(new Color(240, 240, 240)); // Fundo cinza claro
        panelBotoes.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelBotoes.setLayout(new FlowLayout(FlowLayout.CENTER));
        panelBotoes.add(btnCarrinho);

        add(panelBotoes, BorderLayout.SOUTH);
    }

    private JPanel criarPanelProduto(Produto produto) {
        JPanel panelProduto = new JPanel();
        panelProduto.setBackground(Color.WHITE);
        panelProduto.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1));
        panelProduto.setLayout(new BorderLayout());

        JLabel lblNome = new JLabel(produto.getNome());
        lblNome.setFont(new Font("Arial", Font.BOLD, 18));
        lblNome.setHorizontalAlignment(SwingConstants.CENTER);
        panelProduto.add(lblNome, BorderLayout.CENTER);

        JLabel lblPreco = new JLabel("R$ " + produto.getPreco());
        lblPreco.setFont(new Font("Arial", Font.PLAIN, 16));
        lblPreco.setHorizontalAlignment(SwingConstants.CENTER);
        panelProduto.add(lblPreco, BorderLayout.SOUTH);

        JButton btnAdicionar = new JButton("Adicionar ao Carrinho");
        btnAdicionar.setBackground(new Color(0, 153, 0)); // Verde
        btnAdicionar.setForeground(Color.WHITE); // Texto branco
        btnAdicionar.setFont(new Font("Arial", Font.BOLD, 14));
        btnAdicionar.setFocusPainted(false); // Sem foco
        btnAdicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adicionarProdutoAoCarrinho(produto);
                btnAdicionar.setEnabled(false); // Desabilita após adicionar
                btnAdicionar.setText("Adicionado!");
            }
        });
        panelProduto.add(btnAdicionar, BorderLayout.PAGE_END);

        return panelProduto;
    }

    private void adicionarProdutoAoCarrinho(Produto produto) {
        produtosSelecionados.add(produto);
        JOptionPane.showMessageDialog(this, produto.getNome() + " adicionado ao carrinho!");
    }

    private void abrirTelaCarrinho() {
        SwingUtilities.invokeLater(() -> {
            new TelaCarrinho(produtosSelecionados).setVisible(true);
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new TelaVitrineProdutos().setVisible(true);
        });
    }
}











