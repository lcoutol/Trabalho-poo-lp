import java.time.LocalDateTime;
import java.util.List;

public class Venda {
    private Cliente cliente;
    private Vendedor vendedor;
    private List<ItemVenda> itens;
    private LocalDateTime dataHora;

    public Venda(Cliente cliente, Vendedor vendedor, List<ItemVenda> itens) {
        this.cliente = cliente;
        this.vendedor = vendedor;
        this.itens = itens;
        this.dataHora = LocalDateTime.now();
    }

    public Cliente getCliente() {
        return cliente;
    }

    public Vendedor getVendedor() {
        return vendedor;
    }

    public List<ItemVenda> getItens() {
        return itens;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }
}


