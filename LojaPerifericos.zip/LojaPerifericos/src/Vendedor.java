public class Vendedor extends Pessoa {
    private String idFuncionario;
    private double comissao;

    public Vendedor(String nome, String cpf, String idFuncionario, double comissao) {
        super(nome, cpf);
        this.idFuncionario = idFuncionario;
        this.comissao = comissao;
    }

    public String getIdFuncionario() {
        return idFuncionario;
    }

    public double getComissao() {
        return comissao;
    }
}


